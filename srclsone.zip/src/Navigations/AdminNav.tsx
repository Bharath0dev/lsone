import { View, Text } from 'react-native'
import React from 'react'
import { createDrawerNavigator } from '@react-navigation/drawer';
import AdminScreen from '../screens/Admin/AdminScreen';
import CustomerData from '../components/CustomerData';
import ProviderData from '../components/ProviderData';
import ProfileNav from './ProfileNav';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginNav from './LoginNav';


// const AdminStack = ()=>{
//     const Stack = createNativeStackNavigator();
  
//     return(
//       <Stack.Navigator
//       screenOptions={{
//         headerShown: false
//       }}>
//         <Stack.Screen
//         name='AdminHome' component={AdminScreen}/>
//         <Stack.Screen options={{
//           headerShown: false
//         }} name='LoginAd' component={LoginNav}/>
//       </Stack.Navigator>
//     )
//   }

const AdminNav = () => {
  
const Drawer = createDrawerNavigator();

// const CustomerDataWrapper = ({ route, ...props }) => (
//     <CustomerData {...props} route={{ ...route, params: { role: "Customer" } }} />
//     );
    
// const ProviderDataWrapper = ({ route, ...props})=> (
//     <ProviderData {...props} route={{ ...route, params: {role: "ServiceProvider "}}}/>
//     )
    
  return(
    <Drawer.Navigator>
      <Drawer.Screen 
      name='AdminScreen' component={AdminScreen}
      options={{
        drawerLabel: 'Home',
        headerTitle: ()=> null
      }}
      />
      <Drawer.Screen 
      name='CustomerData' 
      // component={(props ) => <CustomerDataWrapper {...props} role = 'Customer'/>}
      component={CustomerData}
      />

      <Drawer.Screen 
      name='ProviderData' 
      // component={(props ) => <ProviderDataWrapper {...props} role = 'ServiceProvider'/>}
      component={ProviderData}
      />
      <Drawer.Screen name='Profilepage' component={ ProfileNav}/>
    
    </Drawer.Navigator>

    
  )
}


export default AdminNav