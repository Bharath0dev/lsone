import { View, Text } from 'react-native'
import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import LoginPage from '../screens/loginandregister/Login';
import ProviderNav from './ProviderNav';
import AdminNav from './AdminNav';
import CustomerNav from './CustomerNav';

const LoginNav = () => {
    const Stack = createNativeStackNavigator();

    return(
      <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}
      >
        <Stack.Screen name='LoginPage' component={LoginPage}/>
        {/* <Stack.Screen name='Register' component={RegisterPage}/> */}
        <Stack.Screen name='Home' component={CustomerNav}/>
        <Stack.Screen name='ProviderScreen' component={ProviderNav}/>
        <Stack.Screen name='AdminScreen' component={AdminNav}/>
      </Stack.Navigator>
    )
}

export default LoginNav