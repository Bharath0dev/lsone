import { View, Text } from 'react-native'
import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import ProviderScreen from '../screens/Provider/ProviderScreen';
import LoginNav from './LoginNav';
import ProfileNav from './ProfileNav';
import services from '../screens/Provider/ProviderServices';
import ProviderServices from '../screens/Provider/ProviderServices';
import Bookings from '../screens/Bookings';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Entypo from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Octicons from 'react-native-vector-icons/Octicons';

const ProviderTab = () =>{
  const Tab = createBottomTabNavigator();

  return(
    <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarLabelStyle: { fontSize: 14 },
      tabBarStyle:{
        backgroundColor: '#00634B',
        height: 60,
        // width: '95%',
        // position: 'absolute',
        // marginHorizontal:10,
        // marginBottom: 5,
        // borderRadius: 10
      },
      tabBarInactiveTintColor: '#9DCFB6',
      tabBarActiveTintColor: 'white',
      
    }}
    >
      <Tab.Screen 
      name='ProviderScreenTab' 
      component={ProviderScreen}
      options={{
        tabBarIcon: ({ color })=>(
          <Entypo name='home' color={ color } size={28}/>
        ),
        headerShown: false,
        tabBarLabel: 'Home',
      }}/>
      <Tab.Screen name='servicesPro' component={ProviderServices}
      options={{
        headerShown: false,
        tabBarLabel: 'Services',
        tabBarIcon: ({ color })=>(
          <Octicons name='tasklist' color={ color } size={28}/>
        ),
      }}
      
      />
      <Tab.Screen 
      name='Bookings' 
      component={Bookings}
      options={{
        tabBarIcon: ({ color })=>(
          <Entypo name='list' color={ color } size={28}/>
        ),
      }}
      />
      <Tab.Screen 
      name='Profile' 
      component={ProfileNav}
      options={{
        tabBarIcon: ({ color })=>(
          <Ionicons name='person' color={color} size={28}/>
        ),
        headerShown: false ,
      }}/>
    </Tab.Navigator>
  )
}
const ProviderNav = () => {
    const Stack = createNativeStackNavigator();

    return (
      <Stack.Navigator screenOptions={{
        headerShown: false
      }}>
        <Stack.Screen  name='ProviderScreen' component={ProviderTab}/>
        {/* <Stack.Screen name='Profile' component={ProfileNav}/>
        <Stack.Screen name='Bookings' component={Bookings}/>
        <Stack.Screen name='servicesPro' component={ProviderServices}/> */}
        {/* <Stack.Screen options={{
          headerShown: false
        }} name='LoginPr' component={LoginNav}/> */}
      </Stack.Navigator>
    )
}

export default ProviderNav