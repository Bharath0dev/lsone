import { View, Text, FlatList, StyleSheet } from 'react-native';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Button } from 'react-native-paper';
import Scheduler from '../components/Scheduler';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ServiceProviders = ({ route }) => {
    const { serviceId, serviceName } = route.params;
    console.log(serviceId, serviceName);

    const [providers, setProviders] = useState([]);
    const [activeScheduler, setActiveScheduler] = useState(null); // Store the active provider's ID

    const [customerId, setCustomerId] = useState('');
    // const [providerId, setProviderId] = useState('');

    const getProviders = async () => {
        try {
            const response = await axios.get('http://192.168.1.218:4021/getProviders', { params: { serviceId } });
            console.log(response.data);
            setProviders(response.data.serviceProviderId);
            console.log(response.data.serviceProviderId);
            // setProviderId(response.data.serviceProviderId[0]._id);
        } catch (error) {
            console.error('Error fetching providers:', error);
        }
    };

    const getUserId = async ()=>{
        const userId= await AsyncStorage.getItem('userId');
        setCustomerId(userId);
    }
    const consoleIds = ()=>{
        // console.log('User Id: ',customerId);
        // console.log('Service Id: ',serviceId);
        // console.log('provider Id: ',providerId);
    }
    useEffect(() => {
        getProviders();
    }, [serviceId]);

    useEffect(()=>{
        getUserId();
    }, [])
    // useEffect(()=>{
    //     consoleIds();
    // }, [])

    function handleScheduler(id) {
        setActiveScheduler(activeScheduler === id ? null : id); // Toggle the active scheduler ID
    }

    return (
        <View style={styles.container}>
            {/* <Text>ServiceProviders</Text>
            <Text>{serviceId}</Text>
            <Text>{serviceName}</Text> */}
            <View style={styles.header}>
            <Text style={styles.headerText}>{serviceName} Providers</Text>
            </View>

            <View>
                <FlatList
                    data={providers}
                    keyExtractor={(item) => item._id}
                    renderItem={({ item }) => (
                      <>

                        <View style={styles.flatlistContainer}>
                            <View style={styles.flatlistText}>
                                <Text style={styles.text}>{item.name}</Text>
                                {/* <Text>Provider Id: {item._id}</Text> */}
                                <Text style={styles.text}>{item.email}</Text>
                                <Text style={styles.text}>{item.mobile}</Text>
                            </View>
                            <View style={styles.btnView}>
                                <Button 
                                style={styles.btn}
                                labelStyle={styles.btnText}
                                onPress={() => handleScheduler(item._id)}>Book</Button>
                            </View>
                        </View>

                        <View>
                          {activeScheduler === item._id && (
                            <Scheduler 
                            customerId={customerId}
                            serviceId={serviceId}
                            providerId={item._id}

                            />)}
                        </View>
                      </>
                        
                    )}
                />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    flatlistContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: 'white',
        marginHorizontal: 12,
        marginVertical: 8,
        borderRadius: 10,
        height: 100,
        alignItems: 'center',
        elevation: 4,
        shadowColor: 'black'       
    },
    container:{
        flex: 1,
        backgroundColor: 'white'
    },
    header:{
        height: 50,
        justifyContent: 'center',
        alignItems: 'center'
    },
    headerText:{
        fontSize: 19,
        fontWeight: 'bold'
    },
    flatlistText:{
        margin: 10,
    },
    text:{
        marginBottom: 6,
        fontSize: 16,
        color: 'black',
        fontWeight: '400',
    },
    btnView:{
        backgroundColor: '#52be80',
        borderRadius: 8,
        marginRight: 10,
    },
    btnText:{
        color: 'white',
        fontSize: 20,
        fontWeight: 'bold'
    }
});

export default ServiceProviders;
