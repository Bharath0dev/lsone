import { Alert, FlatList, Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import UserHomeScreen from '../../components/UserHomeScreen'
import { CommonActions, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Ionicons from 'react-native-vector-icons/Ionicons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';


const Home = () => {

  const [userData, setUserData] = useState('');
  const [alertShown, setAlertShown] = useState(false);

  const [cleaningServices, setCleaningServices] = useState('');
  const [mountingServices, setMountingServices] = useState('');
  const [repairingServices, setRepairingServices] = useState('');


  const navigation = useNavigation();
  const baseURL = 'http://192.168.1.218:4021/';

  async function getData() {
    const token = await AsyncStorage.getItem('token');
    console.log("token in Homepage : ",token);

    console.log(token);

    const res = await axios.post('http://192.168.1.218:4021/userdata', {token: token})
        console.log(res.data);
        setUserData(res.data.data);
        await setData(res.data.data);
  }

  async function setData(userData) {
    if (userData && userData.name && userData.location) {
      await AsyncStorage.setItem('userName', userData.name);
      await AsyncStorage.setItem('location', JSON.stringify(userData.location));
      await AsyncStorage.setItem('role', userData.role)

      console.log(userData.name); 
      console.log(userData.location); 
    } else {
      console.log('userData is not available or does not have a name');
    }
  }
  useEffect(() => {
   getData();
  }, []);
  
  const getCleaningServices = async ()=>{
    const category = "Cleaning";

    const response = await axios.get('http://192.168.1.218:4021/get-services', { params: { category }})
    console.log(response.data);
    setCleaningServices(response.data.data);
  }

  const getMountingServices = async ()=>{
    const category = "Mounting and Installation";

    const response = await axios.get('http://192.168.1.218:4021/get-services', { params: { category }})
    console.log(response.data);
    setMountingServices(response.data.data);
  }

  const getRepairingServices = async ()=>{
    const category = "Repairing";

    const response = await axios.get('http://192.168.1.218:4021/get-services', { params: { category }})
    console.log(response.data);
    setMountingServices(response.data.data);
  }

useEffect(()=>{
  getCleaningServices();
  getMountingServices();
},[])


  useEffect(() => {
    // console.log(userData.location.zip)
    if (userData && userData.location && (userData.location.zip === "" || userData.location.zip === null)) {

      if (!alertShown) {
        navigation.navigate('Profile')
        Alert.alert('Error', 'Zip code is not available.');
        setAlertShown(true); // Set to true to prevent repeated alerts
      }
      
    }
  }, [userData]);


  function handleLogout(){
    try{
      AsyncStorage.setItem('isLoggedIn', JSON.stringify(false));
      AsyncStorage.setItem('token', '');
      
    // navigation.navigate('LoginC');
      navigation.dispatch(
        CommonActions.reset({
          index: 0, 
          routes: [{ name: 'LoginPage' }], 
        })
      );

    }catch (error) {
      console.error("Failed to sign out:", error);
    }
  }

  return (
    <ScrollView>
    <View style={styles.container}>


      {/* {userData && userData.loctaion && userData.loctaion.zip ? (
          <Text>{userData.location.zip}</Text>
        ) : (null)} */}

        <View style={styles.notificationBar}>
          <View>
              {/* <Text style={styles.greet}>Hi,</Text>
              <Text style={styles.userName}>{userName}</Text> 
              <Text style={styles.userName}>Hi, {userName}</Text> */}
          </View>

          <View style={styles.topIcons}>
              <TouchableOpacity >
                  <Ionicons
                      name='notifications' 
                      // color='#52be80' 
                      color = '#00634B'
                      size={25} 
                      style={{margin: 8}}
                      />   
              </TouchableOpacity>
          
              <TouchableOpacity onPress={handleLogout}>
                  <FontAwesome
                      name='sign-out' 
                      // color='#52be80' 
                      color = '#00634B'
                      size={25}
                      style={{margin: 8}}
                      />
              </TouchableOpacity>
          </View>
        </View>

      <View>
        <UserHomeScreen/>
      </View>
      
      <View>
        <View>
            <Text style={styles.serviceHeading}>Cleaning Services</Text>
        </View>
        <View style={styles.servicesContainer}>
            <FlatList
            horizontal
            data={cleaningServices}
            keyExtractor={(item) => item._id}
            renderItem={({item})=>(
              <View style={styles.flatlistContainer}>
                
                <Image source={ {uri: baseURL + item.serviceImage}}
                style={styles.serviceImage}
                onError={() => console.log('Image load error')}
                />
                <Text style={styles.serviceName}>{item.serviceName}</Text>

              </View>
            )}/>
        </View>
      </View>

      <View>
        <View>
            <Text style={styles.serviceHeading}>Mounting Services</Text>
        </View>
        <View style={styles.servicesContainer}>
            <FlatList
            horizontal
            data={mountingServices}
            keyExtractor={(item) => item._id}
            renderItem={({item})=>(
              <View style={styles.flatlistContainer}>
                
                <Image source={ {uri: baseURL + item.serviceImage}}
                style={styles.serviceImage}
                onError={() => console.log('Image load error')}
                />
                <Text style={styles.serviceName}>{item.serviceName}</Text>

              </View>
            )}/>
        </View>
      </View>

      <View>
        <View>
            <Text style={styles.serviceHeading}>Repairing Services</Text>
        </View>
        <View style={styles.servicesContainer}>
            <FlatList
            horizontal
            data={repairingServices}
            keyExtractor={(item) => item._id}
            renderItem={({item})=>(
              <View style={styles.flatlistContainer}>
                
                <Image source={ {uri: baseURL + item.serviceImage}}
                style={styles.serviceImage}
                onError={() => console.log('Image load error')}
                />
                <Text style={styles.serviceName}>{item.serviceName}</Text>

              </View>
            )}/>
        </View>
      </View>


    </View>
    </ScrollView>
  )
}

export default Home

const styles = StyleSheet.create({
  container: {
    // backgroundColor: '#f1fafa',
    backgroundColor: 'white',
  },
  notificationBar:{
    // backgroundColor: 'green',
    height: 45,
    flexDirection: 'row',
    alignItems:'center',
    marginHorizontal: 5,
    justifyContent: 'space-between',
    height: 45,
  },
  topIcons:{
      flexDirection: 'row',
  },
  serviceHeading:{
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    marginHorizontal: 10
  },
  servicesContainer:{},
  flatlistContainer:{
    rowGap: 10,
    margin: 15
  },
  serviceImage:{
    height: 100,
    width: 100,
    borderRadius: 8,
  },
  serviceName:{
    color: 'black',
    fontWeight: '500',

  }
})