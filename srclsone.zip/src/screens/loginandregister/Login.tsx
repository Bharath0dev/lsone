import { View, Text, Image, TextInput, TouchableOpacity, Alert } from 'react-native'
import React, { useState } from 'react'
import { useNavigation } from '@react-navigation/native';
import { ScrollView } from 'react-native-gesture-handler';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './style';
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import Feather from 'react-native-vector-icons/Feather'
import Toast, { BaseToast, ErrorToast } from 'react-native-toast-message';

const LoginPage = () => {
    const navigation = useNavigation();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

     const handleSubmit = async ()=>{
      console.log(email, password);

      const userData ={
        email: email,
        password: password,
    }

    const response = await axios.post('http://192.168.1.218:4021/login-user', userData)
    
      console.log(response.data)

      if(response.data.status == 'ok'){
        // Alert.alert('Login Succesfull');

        Toast.show({
          type: 'success',
          text1: 'welcome',
          text2: 'Logged in',
          visibilityTime: 3000
        })

        await AsyncStorage.setItem('token', response.data.data);
        await AsyncStorage.setItem('userId', response.data.userId);
        await AsyncStorage.setItem('role', response.data.role);
        await AsyncStorage.setItem('isLoggedIn', JSON.stringify(true));

        if(response.data.role === 'Admin' ){
          navigation.navigate('AdminScreen');
        }
        else if(response.data.role === 'Customer'){
          navigation.navigate('Home')
        }
        else if(response.data.role === 'ServiceProvider'){
          navigation.navigate('ProviderScreen');
        }
        setEmail('');
        setPassword('');
      }

  }
  return (
    <ScrollView keyboardShouldPersistTaps={'always'} contentContainerStyle={{flexGrow: 1, justifyContent:'center',  }}>
      <View style={{width: '100%', alignItems: 'center'}}>
        
            <Text style={styles.text_header}>Login!!! </Text>


            <View style={styles.action}>
                <FontAwesome name='user-o' color='#055240' style={styles.smallIcon}/>

                <TextInput 
                placeholder='Email' 
                value={email}
                style={styles.textInput}
                onChange={e => setEmail(e.nativeEvent.text)}
                />
            </View>

            <View style={styles.action}>
                <Feather name='lock' color='#055240' style={styles.smallIcon}/>

                <TextInput 
                placeholder='Password' 
                value={password}
                style={styles.textInput}
                onChange={e => setPassword(e.nativeEvent.text)}
                />
            </View>

            
        {/* <View 
              style={{
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                marginTop: 8,
                marginRight: 10,
              }}>
              <Text style={{ color: '#52be80', fontWeight: '700'}}>Forgot Password</Text>
        </View> */}


        <View style={ styles.button}>
                <TouchableOpacity style={ styles.inBut} onPress={()=> handleSubmit()}>
                  <View>
                    <Text style={ styles.textSign}>Login</Text>
                  </View>
                </TouchableOpacity>
                <View style={{ padding: 15 }}>
                </View>

                  <View style={{flexDirection: 'row', alignItems: 'center', justifyContent:'center'}}>
                    <Text style={{fontSize: 15}}> Don't have an Account? {' '}</Text>
                    <TouchableOpacity 
                    onPress={()=>{ navigation.navigate('Register')}}
                    >
                      <Text style={ styles.signupText }> SignUp</Text>
                    </TouchableOpacity>
                    
                  </View>

            </View>
      </View>
    </ScrollView>
  )
}

export default LoginPage