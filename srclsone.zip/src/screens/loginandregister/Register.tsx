import { View, Text, Image, TextInput, TouchableOpacity, Alert, Button } from 'react-native'
import React, { useEffect, useState } from 'react'
import { ScrollView } from 'react-native-gesture-handler';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native';
import { RadioButton } from 'react-native-paper';
import styles from './style';
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import Feather from 'react-native-vector-icons/Feather'
import Fontisto from 'react-native-vector-icons/Fontisto';
import Error from 'react-native-vector-icons/MaterialIcons';
import Entypo from 'react-native-vector-icons/Entypo'
import { SelectList } from 'react-native-dropdown-select-list';
import FontAwesome6 from 'react-native-vector-icons/FontAwesome6'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import Dropdown from '../../components/Dropdown';

const RegisterPage = () => {

    const [name, setName] = useState('');
    const [nameVerify, setNameVerify] = useState(false);

    const [email, setEmail] = useState('');
    const [emailVerify, setEmailVerify] = useState(false);

    const [mobile, setMobile] = useState('');
    const [mobileVerify, setMobileVerify] = useState(false);

    const [password, setPassword] = useState('');
    const [passwordVerify, setPasswordVerify] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const [street, setStreet] = useState('');
    const [streetVerify, setStreetVerify] = useState(false);

    const [zip, setZip] = useState('');
    const [zipVerify, setZipVerify] = useState(false);

    const [role, setRole] = useState('');
    const [secretText, setSecretText] = useState('');




    const navigation = useNavigation();

    function handleSubmit(){
        
//         const addressData = {
//             street,
//             state,
//             city,
//             zip
//           };

// console.log(addressData);

        const userData = {
            name:name,
            email,
            mobile,
            password,
            role,
            // address: addressData
        };

        if(nameVerify && emailVerify && passwordVerify && mobileVerify){
            if(role == 'Admin' && secretText!='1234'){
                return Alert.alert('Invalid Admin');
            }
            axios.post('http://192.168.1.218:4021/register', userData)
            .then((res)=> {console.log(res.data)
                if(res.data.status == 'ok'){
                    Alert.alert('Registration Successfull');
                    navigation.navigate('Login')
                }else{
                    Alert.alert(JSON.stringify(res.data));
                }
            })
            .catch(e=> console.log(e));
        }else{
            Alert.alert('Fill mandatory details')
        }
    }


    function handleName(e){
        const nameVar = e.nativeEvent.text;
        setName(nameVar);
        setNameVerify(false);

        if(nameVar.length>1){
            setNameVerify(true)
        }
    }

    function handleEmail(e){
        const emailVar = e.nativeEvent.text;
        setEmail(emailVar);
        setEmailVerify(false);

        if(/^[\w.%+-]+@[\w.-]+\.[a-zA-Z]{2,}$/.test(emailVar)){
            setEmail(emailVar);
            setEmailVerify(true);
        }
    }

    function handleMobile(e){
        const mobileVar = e.nativeEvent.text;
        setMobile(mobileVar);
        setMobileVerify(false);
        if(/[6-9]{1}[0-9]{9}/.test(mobileVar)){
            setMobile(mobileVar);
            setMobileVerify(true);
        }
    }

    function handlePassword(e){
        const passwordVar = e.nativeEvent.text;
        setPassword(passwordVar);
        setPasswordVerify(false);
        if(/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+{}\[\]:;<>,.?~`-]).{6,}/.test(passwordVar)){
            setPassword(passwordVar);
            setPasswordVerify(true);
        }
    }
    function handleZip(e){
        const zipVar = e.nativeEvent.text;
        setZip(zipVar);
        setZipVerify(false);
        if(/[0-9]{6}/.test(zipVar)){
            setZip(zipVar);
            setZipVerify(true);
        }
    }

    function handleStreet(e){
        const streetVar = e.nativeEvent.text;
        setStreet(streetVar);
        setStreetVerify(false);
        if(streetVar.length>1){
            setStreetVerify(true)
        }
    }

  return (
    <ScrollView 
    showsVerticalScrollIndicator={false}
    keyboardShouldPersistTaps={'always'}
    contentContainerStyle={{flexGrow: 1, justifyContent:'center' }}>
        <View>
        <View style={styles.logoContainer}>
            <Text style={styles.text_header}>Register!!! </Text>

            <Text style={{alignItems: 'flex-end', width: '100%', marginLeft:65, fontSize: 16, fontWeight: '500'}}>Register as</Text>

            <View style={styles.radioButton_div}>

                <View style={styles.radioButton_inner_div}>
                    <Text style={styles.radio_btn_text}>Customer</Text>
                    <RadioButton 
                    value='Customer' 
                    status={role == 'Customer' ? 'checked' : 'unchecked'}
                    onPress={()=> setRole('Customer')}/>
                </View>

                <View style={styles.radioButton_inner_div}>
                    <Text style={styles.radio_btn_text}>ServiceProvider</Text>
                    <RadioButton 
                    value='Service Provider'
                    status={role == 'ServiceProvider' ? 'checked' : 'unchecked'}
                    onPress={()=> setRole('ServiceProvider')}/>
                </View>

                {/* <View style={styles.radioButton_inner_div}>
                    <Text style={styles.radio_btn_text}>Admin</Text>
                    <RadioButton 
                    value='Admin'
                    status={role == 'Admin' ? 'checked' : 'unchecked'}
                    onPress={()=> setRole('Admin')}/>
                </View> */}
            </View>
            {/* {role == 'Admin' ? (
                <View style={styles.action}>
                    <FontAwesome 
                    name='user-o' 
                    color= '#055240' 
                    style={styles.smallIcon}/>

                    <TextInput
                    placeholder='Secret Text'
                    style={styles.textInput}
                    onChange={ e => setSecretText(e.nativeEvent.text)}
                    />
                </View>
            ):(
                role == 'ServiceProvider' ? (
                    <View style={styles.action}>
                        <Entypo 
                        name='briefcase' 
                        color= '#055240' 
                        style={styles.smallIcon}/>
    
                        <TextInput
                        placeholder='Service name'
                        style={styles.textInput}
                        onChange={ e => setSecretText(e.nativeEvent.text)}
                        />
                    </View>
                ):('')
            )} */}
            

            <View style={styles.action}>
                    <FontAwesome name='user-o' color= '#055240' style={styles.smallIcon}/>
                    <TextInput
                    placeholder='Name'
                    style={styles.textInput}
                    onChange={ e => handleName(e)}
                    />
                    {name.length < 1 ? null : nameVerify ? (
                        <Feather name='check-circle' color='green' size={20} />
                    ):(
                        <Error name='error' color='red' size={20}/>
                    )}
            </View>
                    {name.length < 1 ? null : nameVerify ? null :(
                        <Text
                        style={{ marginLeft: 20, color: 'red'}}>
                            Name should be more than 1 character
                        </Text>
                    )}


            <View style={styles.action}>
                <Fontisto
                name='email' 
                color='#055240' 
                size={24} 
                style={{marginLeft: 0, paddingRight: 5}}
                />

                <TextInput 
                placeholder='Email' 
                style={styles.textInput}
                onChange={e => handleEmail(e)}
                />
                {email.length < 1 ? null : emailVerify ? (
                    <Feather name='check-circle' color='green' size={20} />
                ):(
                    <Error name='error' color='red' size={20}/>
                )}
            </View>
                {email.length < 1 ? null : emailVerify ? null :(
                        <Text
                        style={{ marginLeft: 20, color: 'red'}}>
                            Enter proper email address
                        </Text>
                    )}

            <View style={styles.action}>
                <FontAwesome
                name='mobile'
                color='#055240'
                size={35}
                style={{paddingRight: 10, marginTop: -7, marginLeft:5}}
                />
                <TextInput 
                placeholder='Mobile' 
                style={styles.textInput}
                onChange={(e)=> handleMobile(e)}
                maxLength={10}
                />
                {mobile.length < 1 ? null : mobileVerify ? (
                    <Feather name='check-circle' color='green' size={20} />
                ):(
                    <Error name='error' color='red' size={20}/>
                )}
            </View>
                {mobile.length < 1 ? null : mobileVerify ? null :(
                        <Text
                        style={{ marginLeft: 20, color: 'red'}}>
                            Phone number with 6-9 and remaining 9 digit with 0-9 
                        </Text>
                    )}

            <View style={styles.action}>
                <Feather 
                name='lock' 
                color='#055240' 
                style={styles.smallIcon}/>
                <TextInput 
                placeholder='Password' 
                style={styles.textInput}
                onChange={(e)=> handlePassword(e)}
                secureTextEntry={showPassword}
                />
                <TouchableOpacity onPress={()=> setShowPassword(!showPassword)}>
                    {password.length<1?null: !showPassword?(
                    <Feather
                    name='eye-off'
                    stytle={{marginRight: -10}}
                    color= {passwordVerify ? 'green' : 'red'}
                    size={20}
                    />):(
                        <Feather
                    name='eye'
                    stytle={{marginRight: -10}}
                    color= {passwordVerify ? 'green' : 'red'}
                    size={20}
                    /> 
                    )}
                </TouchableOpacity>
                
            </View> 
            {password.length < 1 ? null : passwordVerify ? null :(
                        <Text
                        style={{ marginLeft: 20, color: 'red'}}>
                            Uppercase, Lowercase, Number and 6 or more characters
                        </Text>
                    )}
            
            {/* <View style={styles.action}>
                <FontAwesome6
                name='house-flag'
                color='#055240'
                size={19}
                style={{paddingRight: 10, marginTop: 2, marginLeft:5}}
                />
                <TextInput 
                placeholder='House no. and Street' 
                style={styles.textInput}
                onChange={(e)=> handleStreet(e)}
                // maxLength={10}

                />
                {street.length < 1 ? null : streetVerify ? (
                        <Feather name='check-circle' color='green' size={20} />
                    ):(
                        <Error name='error' color='red' size={20}/>
                    )}

            </View> */}

                {/* {street.length < 1 ? null : streetVerify ? null :(
                            <Text
                            style={{ marginLeft: 20, color: 'red'}}>
                                Street should be more than 1 character
                            </Text>
                        )} */}
            
        </View>
        
        <View style={ styles.button}>
                <TouchableOpacity 
                style={ styles.inBut} 
                onPress={()=> handleSubmit()}
                >
                <View>
                    <Text style={ styles.textSign}>Register</Text>
                </View>
                </TouchableOpacity>
            </View>
            <View style={styles.smalltextContainer}>
            <Text style={styles.smallText}>
                Already have an accout?{"  "}
            </Text>
            <TouchableOpacity
            onPress={()=> {navigation.navigate('Login')}}
            >
                <Text style={styles.smallTextLink}>Login</Text>
            </TouchableOpacity>
      </View>
        </View>
    </ScrollView>
  )
}

export default RegisterPage