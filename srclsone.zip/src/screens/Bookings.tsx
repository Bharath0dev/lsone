import { FlatList, StyleSheet, Text, View } from 'react-native'
import React, { useCallback, useEffect, useState } from 'react'
import AsyncStorage from '@react-native-async-storage/async-storage'
import axios from 'axios'
import { useFocusEffect } from '@react-navigation/native'
import { Button } from 'react-native-paper'

const Bookings = () => {

  const [userId, setUserId] = useState();
  const [userRole, setUserRole] = useState();
  const [bookingData, setBookingData] = useState();


  const getAsyncData = async () => {
    const storedUserId = await AsyncStorage.getItem('userId');
    const storedUserRole = await AsyncStorage.getItem('role');

    console.log('User id is: ', storedUserId);
    console.log('User role is: ', storedUserRole);

    setUserId(storedUserId);
    setUserRole(storedUserRole);
  }


  useEffect(() => {
    getAsyncData();
  }, [])

  const getBookings = async () => {

    if (!userId) {
      console.log('User ID is not set. Skipping booking fetch.');
      return;
    }

    console.log(userId);

    try {
      const response = await axios.get(`http://192.168.1.218:4021/bookingData/${userId}`);
      console.log(response.data);
      setBookingData(response.data);
    } catch (error) {
      console.log('booking data error: ', error)
    }
  }

  useFocusEffect(
    useCallback(() => {
      getBookings();
    }, [userId])
  )


  const handleResponceButton = async (bookingId, userResponse) => {
    try {
      console.log(bookingId, userResponse);

      const response = await axios.patch(`http://192.168.1.218:4021/updateBookingStatus/${bookingId}/userResponse`, {
        userResponse: userResponse,
      });
      console.log('Status updated successfully:', response.data);
    } catch (error) {
      console.error('Error updating status:', error);
    }

  }


  return (
    <View style={styles.pageContainer}>
      <FlatList
        data={bookingData}
        keyExtractor={(item) => item._id}
        renderItem={({ item }) => (

          <View style={styles.card}>
            {userRole === 'Customer' ? (
              <>
                <Text>Booking ID: {item._id}</Text>
                <Text>ProviderName: {item.providerId.name}</Text>
                <Text>email: {item.providerId.email}</Text>
                <Text>scheduled Date: {item.scheduledDate}</Text>
                <Text>scheduled Time: {item.scheduledTime}</Text>
                <Text>status: {item.status}</Text>

                {item.status === 'pending' ? (
                  <>
                    <View>
                      <Button onPress={() => handleResponceButton(item._id, "canceled")}>Cancel</Button>
                    </View>
                  </>
                ) : (null)}
              </>
            ) : (
              <>
                <Text>Booking ID: {item._id}</Text>
                <Text>CustomerName: {item.customerId.name}</Text>
                <Text>email: {item.customerId.email}</Text>
                <Text>scheduled Date: {item.scheduledDate}</Text>
                <Text>scheduled Time: {item.scheduledTime}</Text>
                <Text>status: {item.status}</Text>
                {item.status === 'pending' ? (
                  <>
                    <View>
                      <Button onPress={() => handleResponceButton(item._id, "confirmed")}>Accept</Button>
                      <Button onPress={() => handleResponceButton(item._id, "declined")}>Decline</Button>
                    </View>
                  </>
                ) : (
                  item.status === 'confirmed' ?
                    (null) : (
                      item.status === 'cancelled' ? 
                      (null) : (
                        item.status === 'declined' ? (null) :
                        (null))))}
              </>
            )}
          </View>
        )}
      />
    </View>
  )
}


export default Bookings

const styles = StyleSheet.create({
  pageContainer: {
    backgroundColor: 'white',
    flex: 1
  },
  card: {
    backgroundColor: 'white',
    margin: 10,
    elevation: 4,
    padding: 10,
    borderRadius: 8
  }
})