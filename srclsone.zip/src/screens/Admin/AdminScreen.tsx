import { View, Text, StyleSheet, Image, FlatList, TouchableOpacity, BackHandler, Alert } from 'react-native'
import React, { useEffect, useState } from 'react'
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { Button } from 'react-native-paper';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import ServicesScreen from '../../components/Services';
// import { FlatList } from 'react-native-gesture-handler';


const AdminScreen = () => {



  const handleBackPress = () => {
    Alert.alert('Exit App', 'Are you sure you want to exit?', [
      {
        text: 'Cancel',
        onPress: () => null,
        style: 'cancel',
      },
      {
        text: 'Exit',
        onPress: () => BackHandler.exitApp(),
      },
    ]);
    return true;
  };

  useFocusEffect(
    React.useCallback(() => {
      BackHandler.addEventListener('hardwareBackPress', handleBackPress);

      return () => {
        BackHandler.removeEventListener('hardwareBackPress', handleBackPress);
      };
    },[]),
  );
  

  const navigation = useNavigation();


  return (

    <View style={styles.main}>
      <ServicesScreen/>
    </View>

  )
}

const styles = StyleSheet.create({
  main:{
    flex:1
  }
})

export default AdminScreen